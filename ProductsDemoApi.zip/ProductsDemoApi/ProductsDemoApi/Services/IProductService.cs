﻿using ProductsDemoApi.Models;

namespace ProductsDemoApi.Services
{
    public interface IProductService
    {
        IEnumerable<Product> GetAll();
        Product? GetById(int id);
    }
}